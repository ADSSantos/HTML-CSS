Hi,
Thank for downloading The Great Summer  :)

This font is personal use only, clik this link to purchase commercial license :
https://fontbundles.net/wellscript-studio/2286302-the-great-summer-font-duo

If you need a custom or corporate license please contact us at: 
wellscriptstudio@gmail.com

if you want to give us a cup coffee, :)
https://paypal.me/wellscript

say hi to our store for more amazing fonts :
https://fontbundles.net/wellscript-studio

Follow our instagram for update : @wellscriptstudio

Thank you & Hope You Like It :)
Wellscript Studio
